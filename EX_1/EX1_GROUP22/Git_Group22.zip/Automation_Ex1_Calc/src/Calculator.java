import java.util.Scanner;
import java.util.*;
public class Calculator {
	static Scanner sc = new Scanner(System.in); // scanner
	static boolean option_ok = true;
	public static Hashtable<Character, Integer> my_dict = new Hashtable<Character, Integer>();
	
	public static void startNewCalc() {
		// Starting new calculator program
		System.out.print("Welcome to bases convertor \n");
		do{
			System.out.print(
							"1 = Convert from decimal to hexadecimal \n"
							+ "2 = Convert from hexadecimal to decimal \n"
							+ "3 = Off\r\n");	
			String ans = sc.next();
			char con = ans.charAt(0);
			if (con == '1' && ans.length() == 1)
			{
				decToHexaConvertor();
				option_ok = continueCalc();
			} else if (con == '2' && ans.length() == 1) {
				hexaToDecimalConvertor();
				option_ok = continueCalc();
			} else if (con == '3' && ans.length() == 1){
				System.out.print("Bye");
			} else { // incorrect menue option
				System.out.print("Error: incorrect option, please choose from ther menu only \n");
				option_ok = false;
			}	
		} while(!option_ok);
	}

	private static void hexaToDecimalConvertor() {
		// This function converts a number from hexadecimal to decimal
		String hex = "";
		System.out.println("Insert a number in hexadecimal base:");
		sc.nextLine();
		hex = sc.nextLine();
		while(!isHexa(hex)) {
			System.out.print("Error: your number is not hexadecimal , please try again\r\n");
			hex = sc.nextLine();
		}
		System.out.print("The matching decimal number is: " + hexaToDec(hex)+ "\n");
	}
	
	private static boolean isHexa(String hex) {
		// This function varify if a string represents decimal base number
		if (hex.isEmpty() == true) {
			return false;	
		}		
		List<Character> charList = Arrays.asList('0', '1', '2', '3', '4', '5', '6', '7', '8', '9','A', 'B', 'C', 'D', 'E', 'F');
	    for (char c : hex.toCharArray()) {
	        if (!charList.contains(Character.toUpperCase(c))) {
	            return false;
	        }
	    }
	    return true;
	}

	private static String hexaToDec(String hex) {
		// This function converts a verified hexadecimal number to decimal
		my_dict.put('A', 10);
		my_dict.put('B', 11);
		my_dict.put('C', 12);
		my_dict.put('D', 13);
		my_dict.put('E', 14);
		my_dict.put('F', 15);
		char lastChar;
		int decimal = 0;
		int counter = 0;
		while (hex !=  "") {
			lastChar = hex.charAt(hex.length() - 1);
			hex = hex.substring(0, hex.length() - 1);
			decimal += convertHexaDigit(lastChar)* Math.pow(16, counter);
			counter++;
		}
		return Integer.toString(decimal);
	}
	
	private static int convertHexaDigit(char lastChar) {
		// TODO Auto-generated method stub
		if (Character.isDigit(lastChar))
			return Integer.parseInt(Character.toString(lastChar));
		else {
			return my_dict.get(Character.toUpperCase(lastChar));
		}
	}

	private static void decToHexaConvertor() {
		// This function converts a number from decimal to hexadecimal
		System.out.println("Insert a number in decimal base:");
		sc.nextLine();
		String dec = sc.nextLine();
		while(!isDec(dec)) {
			System.out.println("Error: your number is not decimal, please try again\r\n");
			dec = sc.nextLine();
		}
		System.out.print("The matching hexadecimal number is: " + decToHexa(dec)+ "\n");
	}
	
	private static String decToHexa(String dec) {
		// This function converts a verified decimal number to hexadecimal
	    int num = Integer.parseInt(dec);
		String con_hexa = "";
	    while (num > 0) {
	        int rest = num % 16;
	        if (rest < 10) {
	        	con_hexa = rest + con_hexa;
	        } else {
	        	con_hexa = (char)('A' + rest - 10) + con_hexa;
	        }
	        num = num / 16;
	    }
	    return con_hexa;
	}

	private static boolean isDec(String dec) {
		// This function verify if a string represents decimal base number
		if (dec.isEmpty()) {
			return false;	
		}
		List<Character> charList = Arrays.asList('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
	    for (char c : dec.toCharArray()) {
	        if (!charList.contains(Character.toUpperCase(c))) {
	            return false;
	        }
	    }
	    return true;
	}

	private static boolean continueCalc() {
		// This function checks if the user would like to continue using the convertor
		System.out.print("Would you like to continue and convert another number? : y = yes\n");
		char ans = sc.next().charAt(0);
		if (Character.toLowerCase(ans) == 'y') 
			return false;
		else
			System.out.print("Bye");
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		startNewCalc();
	}
}
