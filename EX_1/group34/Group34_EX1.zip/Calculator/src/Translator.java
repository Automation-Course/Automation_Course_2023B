import java.util.Vector;
import java.util.Scanner;

public class Translator {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int choise = 0;
		while(choise == 0) {
			System.out.println("Hello, in what base number would you like to convert? ");
			int base;
			while(true) {
				int a = scanner.nextInt();
				if((a != 10) && (a != 16)) {
					System.out.println("Oops, you can choose between 10 and 16. try again\n");
				}
				else {
					base = a;
					break;
				}
			}
			while(true) {
				System.out.println("Enter the number you want to convert: ");
				String b = scanner.next();
				if(ValidCheck(b, base)) {
					convert(base, b);
					break;
				}
				else {
					System.out.println("Oops, the number you entered is incorrect. \nPlease enter a valid number.");
				}
			}
			System.out.println("To convert another number press 0, to end the program press 1");
			choise = scanner.nextInt();
		}
	}

public static void convert(int base, String number) { //A wrapper function for the conversion functions
	if(base == 10) {
		int num = Integer.valueOf(number);
		System.out.println(from10to16(num));
	}
	else {
		System.out.println(from16to10(number));
	}
}

 private static String from10to16(int x) { //Conversion function from base 10 to base 16 by calculating residues
	 String[] arr = {"A","B","C","D","E","F"};
	 String answer = "";
	 int rest=x;
	 Vector<String> restVector = new Vector<>();
	 if(x == 0) {
		 answer += "0";
		 return answer;
	 }
	 while(rest != 0) {
		 if(rest%16 < 10) {
			 restVector.add(String.valueOf(rest%16));
		 }
		 else {
			 restVector.add(arr[rest%16-10]);
		 }
		 rest = (int)(rest/16);
	 }
	 
	 for(int i=(restVector.size()-1); i>=0; i--) {
		 answer += String.valueOf(restVector.get(i));
	 }
	 
	 return answer;
 }
 
 public static int from16to10(String x ) { //Conversion function from base 16 to base 10
		int len = x.length();
		int answer = 0;
		for (int i =0; i < len ; i++) {
			int digit;
			char c = x.charAt(len-1-i);
			if(Character.isDigit(c)) {
				digit = Character.getNumericValue(c);
			}
			else {
				c =Character.toUpperCase(c);
				digit = c -55;
			}
			answer += digit*Math.pow(16, i);
		}
		return answer;
}
 
 public static boolean ValidCheck(String input, int base) { //A function that checks the correctness of the input entered by the user
	 String ValidChart10 = "0123456789";	
	 String ValidChart16 = "0123456789abcdefABCDEF";
				for (int i = 0; i < input.length(); i++) {
					char c = input.charAt(i);
					if(base==10) {
						if (ValidChart10.indexOf(c) == -1) {
							return false;
						}
					}
					else {
						if (ValidChart16.indexOf(c) == -1) {
							return false;
						}
					}	
				}
		return true;
	}
}
